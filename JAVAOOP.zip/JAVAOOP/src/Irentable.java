public interface Irentable {
    void rent(Customer customer,int days);

    void returnVehicle();
}
